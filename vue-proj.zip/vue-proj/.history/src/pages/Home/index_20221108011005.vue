<template>
    <div class="flexCenter">
        Home Page
    </div>
</template>

<script>
    export default {
        name: "Home"
    }
</script>

<style lang="css" scoped>
.flexCenter {
  display: flex;
  justify-content: center;
}
</style>