<template>
    <div class="flexCenter">
        Home Page
    </div>
</template>

<script>
    export default {
        name: "Home"
    }
</script>

<style lang="css" scoped>
.flexCenter {
font-size: large;
font-family:Arial, Helvetica, sans-serif;
  display: flex;
  justify-content: center;
}
</style>