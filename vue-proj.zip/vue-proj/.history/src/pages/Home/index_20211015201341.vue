<template>
    <div class="flexCenter">
        home page
    </div>
</template>

<script>
    export default {
        name: "Home"
    }
</script>

<style lang="css" scoped>
.flexCenter {
  display: flex;
  justify-content: center;
}
</style>