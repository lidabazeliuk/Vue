<template>
  <div>
    <card-list/>

  </div>
</template>

<script>
import CardList from "@/components/CardList"

export default {
  name: 'List',
  components: {
    CardList
  },
  data() {
    return {
      
    }
  },
}
</script>

<style>
</style>
